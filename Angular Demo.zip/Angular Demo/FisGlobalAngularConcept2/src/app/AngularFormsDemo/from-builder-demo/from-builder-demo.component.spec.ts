import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FromBuilderDemoComponent } from './from-builder-demo.component';

describe('FromBuilderDemoComponent', () => {
  let component: FromBuilderDemoComponent;
  let fixture: ComponentFixture<FromBuilderDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FromBuilderDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FromBuilderDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
