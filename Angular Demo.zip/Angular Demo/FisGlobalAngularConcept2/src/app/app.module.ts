import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{FormsModule,ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PushSpliceWithForDemoComponent } from './AngularConcepts/push-splice-with-for-demo/push-splice-with-for-demo.component';
import { TemplateDrivenFormDemoComponent } from './AngularFormsDemo/template-driven-form-demo/template-driven-form-demo.component';
import { ReactiveFormDemoComponent } from './AngularFormsDemo/reactive-form-demo/reactive-form-demo.component';
import { FromBuilderDemoComponent } from './AngularFormsDemo/from-builder-demo/from-builder-demo.component';
import { AddUserComponent } from './CurdUserWithWebAPI/add-user/add-user.component';
import { UpdateUserComponent } from './CurdUserWithWebAPI/update-user/update-user.component';
import { DeleteUserComponent } from './CurdUserWithWebAPI/delete-user/delete-user.component';
import { DetailsUserComponent } from './CurdUserWithWebAPI/details-user/details-user.component';
import { UsersListComponent } from './CurdUserWithWebAPI/users-list/users-list.component';
import {Routes, RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

const  appRoutes: Routes=[
  {path:'AddUser',component:AddUserComponent},
  {path:'UsersList',component:UsersListComponent},
  {path:'UpdateUser/:id',component:UpdateUserComponent},
  {path:'DeleteUser',component:DeleteUserComponent},
  {path:'DetailsUser',component:DetailsUserComponent}
]



@NgModule({
  declarations: [
    AppComponent,
    PushSpliceWithForDemoComponent,
    TemplateDrivenFormDemoComponent,
    ReactiveFormDemoComponent,
    FromBuilderDemoComponent,
    AddUserComponent,
    UpdateUserComponent,
    DeleteUserComponent,
    DetailsUserComponent,
    UsersListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
