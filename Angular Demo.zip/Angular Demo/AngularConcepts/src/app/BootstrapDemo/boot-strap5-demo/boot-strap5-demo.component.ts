import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boot-strap5-demo',
  templateUrl: './boot-strap5-demo.component.html',
  styleUrls: ['./boot-strap5-demo.component.css']
})
export class BootStrap5DemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
