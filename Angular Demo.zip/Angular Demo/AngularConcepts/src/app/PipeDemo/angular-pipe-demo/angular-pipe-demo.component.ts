import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-pipe-demo',
  templateUrl: './angular-pipe-demo.component.html',
  styleUrls: ['./angular-pipe-demo.component.css']
})
export class AngularPipeDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  todayNumber: number = Date.now();
  todayDate: Date = new Date();
  todayString: string = new Date().toDateString();
  todayISOString: string = new Date().toISOString();

  Name  : string ="ABHISHEK SHARMA"
  today : number = Date.now();
  msg : string = "This is demo text"


  products = [
    { id: 'pro1001', proimg: "", name: "Laptop", price: 35000 },
    { id: 'pro1002', proimg: "", name: "Mobile", price: 15000 },
    { id: 'pro1003', proimg: "", name: "Pen Drive", price: 1500 },
    { id: 'pro1004', proimg: "", name: "Led", price: 12000 }
  ]

}
