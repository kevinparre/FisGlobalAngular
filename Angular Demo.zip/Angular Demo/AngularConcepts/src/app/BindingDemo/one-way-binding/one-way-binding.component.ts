import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-way-binding',
  templateUrl: './one-way-binding.component.html',
  styleUrls: ['./one-way-binding.component.css']
})
export class OneWayBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  //#1 ONE WAY DATA BINDING  
  // DATABINDING = COMMUNICATION 
  // TS(COMPONENT) ==> HTML(VIEW)

  dynamicName: string = "Abhishek";
  myMethod() {
    return "This is data binding in Angular " + this.dynamicName
  }
  appStatus: boolean = true;
  status1: string = "OnLine";
  status2: string = "Offline";

  enable: boolean = true;
  msg: string = "";
  onAddCart() {
    this.msg = "Product add to cart"
  }
  onInputClick(event: any) {
    console.log(event)
  }
  //myStyle = "15px";
  myStyle = {
    'background': 'red',
    'border': '10px soild green'
  }

  mltClasses = {
    class1: true,
    class2: true,//if you want either of the class no to call , you can also mark it  false
    class3: false
 
  }
}
